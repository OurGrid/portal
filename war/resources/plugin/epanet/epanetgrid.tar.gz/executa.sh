#!/bin/bash

# $1 -> *.inp
# $2 -> saida
# $3 -> result

java -Djava.library.path=lib/linux -cp classes org.ourgrid.epanetgrid.JEpanetToolkitMain $1 $2 $3
